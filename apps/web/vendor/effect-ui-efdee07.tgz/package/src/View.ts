/**
 * Views are values: a tree of element, text and child nodes that a component's
 * `view` returns and a host renders.
 *
 * The core `h` has only `el` and `text`. A child component is declared by
 * calling it with `h`, and a feature by its `render`. An element vocabulary
 * such as the HTML one adds element names and its own element class, supplied
 * through a vocabulary constructor such as `Html.component` or by passing
 * `elements` to `Component.define`.
 *
 * An element is written as a chain: `h.el("form").on("submit", msg).children(...)`.
 * `children` returns the builder, so the chain goes on, and a second call
 * adds after the first. `h.el(tag, ...children)` is shorthand for it. A
 * builder is itself a valid child or view, with the children it holds.
 * Arrays of children are flattened, and `false`, `null` and
 * `undefined` render nothing. Adjacent text merges into one text node when
 * the view is built, and empty text is dropped.
 *
 * **Example** (A host-neutral view)
 *
 * ```ts import.meta.vitest
 * import type { View } from "@effect/ui"
 * import { UiSchema } from "@effect/ui"
 * import { Schema } from "effect"
 *
 * const Message = UiSchema.TaggedEnum({ ClickedIncrement: {} })
 *
 * const view = (count: number, h: View.Helper<typeof Message.Type, {}>) =>
 *   h.el("div", h.el("button").on("click", Message.ClickedIncrement()).children("+"), String(count))
 * ```
 *
 * @stability experimental
 * @since 0.1.0
 */
import type * as AsyncResult from "effect/reactivity/AsyncResult"
import * as Command from "./Command.ts"
import type * as Component from "./Component.ts"
import type * as Feature from "./Feature.ts"
import type * as Head from "./Head.ts"
import type * as MountModule from "./Mount.ts"
import type * as Renderer from "./Renderer.ts"

/**
 * A node of a view: an element, text, or a child component.
 *
 * **Details**
 *
 * `Msg` is the message type the view's handlers send. `R` collects the
 * requirements of the children declared by value, which surface in the
 * parent's requirements.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type Node<Msg, R = never> =
  | Element<Msg, R>
  | Text
  | Child<Msg, R>
  | Outlet

/**
 * Where a component places what its parent passed for one of its slots:
 * `h.slots.body`.
 *
 * **Details**
 *
 * An outlet is opaque: the view that places it can't read the content. The
 * content keeps its own nodes, so an element key in it can't clash with the
 * outlet's siblings, and the outlet is keyed by its slot's name among them.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface Outlet {
  readonly _tag: "Outlet"
  /** The slot's name. */
  readonly name: string
  /**
   * Set when the outlet sits in an element that can't hold text: the error a
   * content with text fails its author with.
   *
   * @internal
   */
  readonly noText?: string | undefined
}

/**
 * A text node.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface Text {
  readonly _tag: "Text"
  readonly text: string
}

/**
 * What an event sends: a message value, or a function of the event's payload
 * that returns `undefined` to ignore the event.
 *
 * **Details**
 *
 * Payloads are plain data declared by the vocabulary and built by the host.
 * No host event object reaches component code, so a test fires one with a
 * literal.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type Handler<Msg, Payload> =
  | Msg
  | ((payload: Payload) => Msg | undefined)

/**
 * How a host treats one event of an element, set with the handler by `on`.
 *
 * **Details**
 *
 * With `preventDefault: true`, the host cancels the event's default action
 * when the handler produces a message, after the handler runs and before the
 * message is sent. A handler that returns `undefined` leaves the event alone,
 * so one handler decides per event, such as Enter but not Shift+Enter. A
 * message value always prevents. With `preventDefault: "always"`, the host
 * cancels the default whatever the handler returns. A host whose events have
 * no default ignores it.
 *
 * Nothing stops an event's propagation. A host gives each event to the
 * innermost element with a handler for it, and only that one, even when the
 * handler returns `undefined`.
 *
 * A vocabulary may extend these options for its own events, such as what a
 * drop target accepts. They stay plain data on the element: hosts and tests
 * read what they know and ignore the rest.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface EventOptions {
  readonly preventDefault?: boolean | "always" | undefined
}

/**
 * Who a layer of an element belongs to: one headless instance. The runtime
 * makes one per instance, and a story one per expanded child.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface Owner {
  readonly path: string
  readonly depth: number
}

/**
 * What a part of a headless component added to an element: its handlers,
 * their options, its ref and its mount, kept apart from the author's.
 *
 * **Details**
 *
 * `tokens` holds the part's token-list attributes, such as `class` and
 * `aria-describedby`. They're added to the element's own value, whether the
 * consumer set it before or after applying the part, and a token already
 * there isn't repeated. The part's other attributes are written over what
 * the consumer set before applying it.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface Owned {
  readonly owner: Owner
  readonly handlers: Readonly<Record<string, Handler<any, any>>>
  readonly eventOptions: Readonly<Record<string, EventOptions>>
  readonly refKey: string | undefined
  readonly mount: Mount<any> | undefined
  readonly tokens: Readonly<Record<string, string>>
}

/**
 * The attributes whose value is a space-separated list, which a part adds
 * its tokens to rather than replacing: `class`, `rel` and the ARIA
 * attributes that list ids.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export const tokenListAttributes: ReadonlySet<string> = new Set([
  "class",
  "rel",
  "aria-controls",
  "aria-describedby",
  "aria-flowto",
  "aria-labelledby",
  "aria-owns"
])

const noOwned: ReadonlyArray<Owned> = []
// What an element built without children holds: one frozen array for all of them.
const noChildren: ReadonlyArray<never> = Object.freeze([])

/**
 * The attributes, properties, handlers and event options of a builder that
 * has set none. One frozen record that every such builder shares, so the
 * runtime and a host know an empty one by looking at it, without reading it.
 *
 * @internal
 */
export const noFields: Readonly<Record<string, never>> = Object.freeze({})

/**
 * An element node, as data.
 *
 * **Details**
 *
 * `attrs` are strings set as attributes. `props` are typed values the host
 * decides the meaning of. `handlers` map an event name to its handler, so
 * re-rendering never touches listeners, and `eventOptions` holds the
 * `EventOptions` set with a handler. `key` keeps the element's node when
 * its siblings move; unkeyed elements match by position. `refKey` names the
 * element for ref Commands, and `mount` is the work started by `onMount`.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface Element<out Msg, out R = never> {
  readonly _tag: "Element"
  readonly tag: string
  readonly elementKey: string | undefined
  readonly attrs: Readonly<Record<string, string>>
  readonly props: Readonly<Record<string, unknown>>
  readonly handlers: Readonly<Record<string, Handler<Msg, any>>>
  readonly eventOptions: Readonly<Record<string, EventOptions>>
  readonly refKey: string | undefined
  readonly mount: Mount<Msg> | undefined
  /**
   * The layers the parts of headless components added, in the order they
   * were applied. An element written by hand may leave it out.
   */
  readonly owned?: ReadonlyArray<Owned> | undefined
  readonly children: ReadonlyArray<Node<Msg, R>>
}

/**
 * What `onMount` stores: the issued mount, with its name, its args and the
 * map from its result to a message.
 *
 * **Details**
 *
 * It's data: a story reads `name` and `args` off it without running the
 * body. See `Mount.make`.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type Mount<Msg> = MountModule.Issued<
  Msg | Component.Noop,
  any,
  any,
  never
>

/**
 * The text of the type error `onMount` gives for a mount that doesn't end
 * with a message or `Component.noop`, such as one whose body is an
 * `Effect<void>` or whose result hasn't been mapped.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type MountHint =
  "onMount's mount ends with a message or Component.noop. Map its result with Mount.map, or end its body with Effect.as(Component.noop)"

/**
 * A child component, declared by calling a component with the
 * parent's `h`, `Editor(h, { key })`, or with a feature's `render`,
 * `Todos.render(h, { key, fallback })`.
 *
 * **Details**
 *
 * The runtime gives each child its own instance, Model and Scope, at the path
 * `Name[key]` under its parent. Several instances of one component are
 * several children with different keys. The child reports up through
 * `onEmit`, checked against the parent's message type, and every child is a
 * failure boundary: a failed child shows `fallback`, or nothing, until its
 * key changes, and the parent's optional `onFailure` is also messaged.
 *
 * A child dropped from the view unmounts, and its Model goes with it. A
 * child written inside `h.keepAlive` with the `s` it passes is kept instead,
 * so the user finds it as they left it: a hidden tab with a half-filled form,
 * a wizard step, a row a filter hides. Keeping is decided where the child is
 * written, `h.keepAlive((s) => Profile(s, { key: "profile" }))`, so the same
 * component can be kept in one view and unmount in another. A kept child
 * belongs to the component whose view called `h.keepAlive`, its author. Its
 * path is `Name[key]` under the author wherever the view puts it, so moving
 * it to another element or into another child's slot keeps the instance.
 *
 * While no view writes it, the runtime keeps its nodes out of the document,
 * and the child keeps its Model, its Commands in flight, its Subscriptions
 * and what the user typed into its inputs. It still gets `$.send` and query
 * results, and its events reach the author's `update` through the `onEmit`
 * of the last render that placed it. It contributes no head entries and no
 * reports to `collects`, a ref lookup inside it finds nothing, and its
 * element mounts stop until it's written again. The log records `Kept` and
 * `Drawn`. Saved state, from the server or a history entry, holds a kept
 * child's Model, and the child takes it once it's written again.
 *
 * Without a predicate it lives as long as its author. With one,
 * `h.keepAlive(({ key, model }) => key in model.rows, (s) => ...)`, the runtime
 * asks the predicate about each live child on every render of the author and
 * ends the child once it says no.
 *
 * **Gotchas**
 *
 * A child without a key has the empty key, at `Name[]`, so it must be the only
 * child of its component where it is rendered: a second one fails the parent
 * with an error that asks for a `key`. Rows in a list always need a key. A
 * list of one unkeyed row renders, and a row that replaces it keeps its
 * instance and Model.
 *
 * Two children at one path are one instance, whatever branch of the view
 * declared them: `cond ? Listbox(h, { props: a }) : Listbox(h, { props: b })`
 * keeps the Model when `cond` changes, and `init` doesn't run again. Key each
 * branch when the component's Model holds state that shouldn't carry over.
 *
 * A kept child costs what a shown one does. Its Subscriptions keep running,
 * so gate one on the Model when it should pause. A dialog or popover open
 * inside it closes when it's kept, and focus inside it is lost. A host
 * without `createContainer` fails the author of a kept child. The props and
 * `onEmit` it has are those of the last render that placed it: write it
 * inside a `hidden` element instead when it needs fresh ones.
 *
 * Every component called with `s` is kept, so a child of an `h.keepAlive`
 * block that should unmount is called with `h`. A child whose call changes
 * from `h` to `s` from one render to the next keeps its instance, and is
 * kept from then on. Changed back, it's an ordinary child again. One
 * component written with `h` and with `s` at one key in one render is one
 * path claimed twice, which fails the author.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface Child<out Msg, out R = never> {
  readonly _tag: "Child"
  /**
   * A component value, a lazy component whose module loads when it mounts, or a feature service
   * resolved from the instance's context when it mounts.
   */
  readonly component: Component.Any | Component.Lazy.Any | Feature.Any
  /** The child's key. */
  readonly key: string
  readonly props: unknown
  readonly onEmit: (events: any) => Msg | undefined
  /** What shows in the child's place while it can't be shown. Required for a feature child. */
  readonly fallback:
    | ((
      result:
        | AsyncResult.Initial<never, unknown>
        | AsyncResult.Failure<never, unknown>
    ) => Content<Msg, any>)
    | undefined
  /** Also tells the parent that the child failed. */
  readonly onFailure:
    | ((failure: AsyncResult.Failure<never, unknown>) => Msg | undefined)
    | undefined
  /** A headless child's whole view, written by whoever declared the child. */
  readonly view: ((parts: any) => Content<Msg, any>) | undefined
  /** What the parent passed for each of the child's slots. */
  readonly slots: Readonly<Record<string, Input<any, any>>> | undefined
  /**
   * Set when the child is written with the `s` of `h.keepAlive`: the block's
   * predicate, or `true` for a block without one.
   */
  readonly alive?: ((input: any) => boolean) | true | undefined
  /** The headless instance that declared the child with `p.child`, which takes its events and failures. */
  readonly owner?: Owner | undefined
  /** Phantom: the child's requirements surface in its parent's. */
  readonly "~R"?: (_: never) => R
}

/**
 * Helper types for `Child`.
 *
 * @stability experimental
 * @since 0.1.0
 */
export declare namespace Child {
  /**
   * The options of a child: what a component call and a feature's `render`
   * take. `props` may be left out when the component takes none.
   *
   * **Details**
   *
   * Without a `key`, the child's key is the empty string, so `key: ""` and
   * no key name the same child.
   *
   * A component call adds one rule: a component whose props are erased,
   * such as a `Component.Any`, takes `props` even when it needs none.
   *
   * @category models
   * @since 0.1.0
   */
  export type Options<Props, Events, Msg> =
    & {
      /** The child's identity among its parent's children of one component. The empty string by default. */
      readonly key?: string | undefined
      /**
       * Handle the child's events with a callback, or supply one handler per tag for tagged events.
       * Return a parent message to dispatch it, or `undefined` to ignore the event.
       */
      readonly onEmit?:
        | ((events: Events) => Msg | undefined)
        | EmitHandlers<Events, Msg>
        | undefined
      /** Also tells the parent that the child failed. The failure stays in the child either way. */
      readonly onFailure?:
        | ((failure: AsyncResult.Failure<never, unknown>) => Msg | undefined)
        | undefined
    }
    & ({} extends Props ? { readonly props?: Props | undefined }
      : { readonly props: Props })

  /**
   * One handler for each tag in a child's event union.
   *
   * @category models
   * @since 0.1.0
   */
  export type EmitHandlers<Events, Msg> = [Events] extends [never] ? never
    : [Events] extends [{ readonly _tag: string }]
    // Reject a wide tag with a conditional on a fixed type: one on a type that depends on Events wouldn't relate
    // for two Events, and would fail a variance check.
      ? [(tag: EventTag<Events>) => void] extends [(tag: string) => void] ?
        never
      : {
        readonly [T in EventTag<Events>]: (
          event: Extract<Events, { readonly _tag: T }>
        ) => Msg | undefined
      }
    : never

  /**
   * The options a component call takes: `Options`, with the key checked
   * against the `h.keepAlive` block when the call is given its `s`. `K` is
   * the key as written, and `Ends` is `true` in a block with a predicate,
   * and `never` for a call given `h`. In a block without a predicate, the
   * key's type must be a literal, so the source fixes how many children the
   * block can keep.
   *
   * @category models
   * @since 0.1.0
   */
  export type KeepAliveOptions<Props, Events, Msg, K, Ends extends boolean> =
    & {
      /** The child's identity among its parent's children of one component, or a kept child's among its author's. The empty string by default. */
      readonly key?: KeepAliveKey<K, Ends> | undefined
      /**
       * Handle the child's events with a callback, or supply one handler per tag for tagged events.
       * Return a parent message to dispatch it, or `undefined` to ignore the event.
       */
      readonly onEmit?:
        | ((events: Events) => Msg | undefined)
        | EmitHandlers<Events, Msg>
        | undefined
      /** Also tells the parent that the child failed. The failure stays in the child either way. */
      readonly onFailure?:
        | ((failure: AsyncResult.Failure<never, unknown>) => Msg | undefined)
        | undefined
    }
    & ({} extends Props ? { readonly props?: Props | undefined }
      : { readonly props: Props })
}

type KeepAliveKey<K, Ends extends boolean> = [Ends] extends [true] ? K
  : true extends WideKey<K> ? KeepAliveKeyHint
  : K

type WideKey<K> = K extends string ? {} extends Record<K, 1> ? true : false
  : false

/**
 * The type a key takes when it needs a predicate, so the error names the fix.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type KeepAliveKeyHint =
  "A keep-alive child whose key isn't a literal needs a predicate that says when it ends: h.keepAlive(($) => ..., (s) => ...)"

/**
 * `s`, what `h.keepAlive` gives its content: `h`, marked as written in an
 * `h.keepAlive` block. A component called with it is kept alive. `Ends` is
 * `true` in a block with a predicate. A function that takes `s` types it
 * `KeepAlive<Msg, true>` to write children whose keys aren't literals,
 * `KeepAlive<Msg, false>` for a block without a predicate, or
 * `KeepAlive<Msg>` for either, where keys must be literals.
 *
 * **Gotchas**
 *
 * Every component called with `s` is kept, so pass `h` to any child in the
 * block that shouldn't be. A headless component, or a feature's `render`,
 * takes `s` as it takes `h`, and its child isn't kept. A function whose
 * parameter is typed `View.Helper` drops the brand: a component it calls with
 * the `s` it's handed is kept, with no check on its key.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface KeepAlive<Msg, out Ends extends boolean = boolean>
  extends HelperBase<Msg, unknown>
{
  /** Phantom: the brand only `h.keepAlive` gives. */
  readonly "~keepAlive": Ends
}

type EventTag<Events> = Events extends { readonly _tag: infer T extends string }
  ? T
  : never

/**
 * One child argument of an element: a node, an element builder, text, an
 * array of them, or a hole (`false`, `null`, `undefined`) that renders
 * nothing. `R` is what the child requires, as for `Content`.
 *
 * **When to use**
 *
 * Use to type the children a shared view helper passes on. Leaving `R` out
 * accepts only children that need no service, so a child that needs one
 * fails at the call site. To pass on whatever the children need, take them
 * with a generic `Children` constraint, as in the example: the element adds their
 * requirements to its own.
 *
 * **Gotchas**
 *
 * `Input<Msg, any>` as a parameter's type, outside a generic, erases what
 * the children require.
 *
 * **Example** (A view helper that keeps its children's requirements)
 *
 * ```ts
 * import type { View } from "@effect/ui"
 * import type { Html } from "@effect/ui/html"
 *
 * const Field = <M, C extends View.Children<M>>(h: Html.H<M>, options: {
 *   readonly label: string
 *   readonly children: C
 * }) => h.label.children(options.label, h.div.class("control").children(options.children))
 * ```
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type Input<Msg, R = never> =
  | Content<Msg, R>
  | string
  | false
  | null
  | undefined
  | Children<Msg, R>

/**
 * A readonly array of children. Use `C extends View.Children<Msg>` for a
 * wrapper's children option to preserve each child's requirements, and pass
 * that option directly to `.children(options.children)` without spreading it.
 * The default requirement is `any` for generic constraints, not annotations:
 * annotating a value as `Children<Msg>` erases its requirements.
 *
 * @stability experimental
 * @category utility types
 * @since 0.1.0
 */
export type Children<Msg, R = any> = ReadonlyArray<
  Content<Msg, R> | string | false | null | undefined
>

/**
 * What a view, a child and a fallback may return: a node, or an element
 * builder with no children yet, such as `h.br` or `h.input.value(draft)`.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type Content<Msg, R = never> =
  | Node<Msg, R>
  | ElementBuilder<Msg, R, any, any>

/**
 * The requirements of a tuple of children, collected one at a time, so two
 * siblings with different needs give the union. `Requirements<any>` is
 * `any`.
 *
 * @stability experimental
 * @category utility types
 * @since 0.1.0
 */
export type Requirements<T> = 0 extends 1 & T ? any :
  T extends string | false | null | undefined ? never
  : T extends Text | Outlet ? never
  : T extends ReadonlyArray<infer E> ? Requirements<E>
  : T extends Child<infer _Msg, infer R> ? R
  : T extends Element<infer _Msg, infer R> ? R
  : T extends ElementBuilder<infer _Msg, infer R, any, any> ? R
  : never

/**
 * Builds a text node.
 *
 * @stability experimental
 * @category constructors
 * @since 0.1.0
 */
export const text = (text: string): Text => ({ _tag: "Text", text })

/**
 * Normalises element children: holes are dropped, arrays are flattened,
 * element builders become elements with no children, and adjacent text
 * merges into one node with empty text dropped.
 *
 * **Details**
 *
 * The view value never holds two text nodes side by side, so server HTML
 * hydrates without separator comments.
 *
 * @stability experimental
 * @category constructors
 * @since 0.1.0
 */
export const children = <Msg>(
  inputs: ReadonlyArray<Input<Msg, any>>
): Array<Node<Msg, any>> => {
  const out: Array<Node<Msg, any>> = []
  for (let i = 0; i < inputs.length; i++) {
    const input = inputs[i]
    if (Array.isArray(input)) {
      for (let j = 0; j < input.length; j++) pushChild(out, input[j])
    } else {
      pushChild(
        out,
        input as Content<Msg, any> | string | false | null | undefined
      )
    }
  }
  return out
}

const pushChild = <Msg>(
  out: Array<Node<Msg, any>>,
  input: Content<Msg, any> | string | false | null | undefined
): void => {
  if (input === false || input === null || input === undefined) return
  if (typeof input === "string") {
    if (input === "") return
    const last = out.length === 0 ? undefined : out[out.length - 1]
    if (last !== undefined && last._tag === "Text") {
      out[out.length - 1] = text(last.text + input)
    } else out.push(text(input))
    return
  }
  const node: Node<Msg, any> = toNode(input)
  if (node._tag === "Text") {
    if (node.text === "") return
    const last = out.length === 0 ? undefined : out[out.length - 1]
    if (last !== undefined && last._tag === "Text") {
      out[out.length - 1] = text(last.text + node.text)
      return
    }
  }
  out.push(node)
}

/**
 * Whether a value is an element builder.
 *
 * @stability experimental
 * @category guards
 * @since 0.1.0
 */
export const isElementBuilder = (
  u: unknown
): u is ElementBuilder<unknown, unknown, unknown, unknown> =>
  u instanceof ElementBuilder

/**
 * Turns view content into a node: an element builder becomes its element,
 * with the children it holds, and a node is returned as it is.
 *
 * @stability experimental
 * @category constructors
 * @since 0.1.0
 */
export const toNode = <Msg, R>(content: Content<Msg, R>): Node<Msg, R> =>
  content instanceof ElementBuilder ? buildWith(content, noChildren) : content

/**
 * Builds the element node a builder describes: the children it holds, then
 * the given ones, normalised as `children` does.
 *
 * **When to use**
 *
 * Use when a finished node is needed, such as in a function declared to
 * return a `View.Element`. A view, a child and a fallback take the builder
 * as it is.
 *
 * @stability experimental
 * @category constructors
 * @since 0.1.0
 */
export const build = <Msg, R, const C extends ReadonlyArray<Input<Msg, any>>>(
  builder: ElementBuilder<Msg, R, any, any>,
  inputs: C
): Element<Msg, R | Requirements<C[number]>> =>
  buildWith(builder, inputs.length === 0 ? noChildren : children(inputs))

const buildWith = <Msg, R>(
  builder: ElementBuilder<Msg, any, any, any>,
  given: ReadonlyArray<Node<Msg, any>>
): Element<Msg, R> => {
  // What the builder holds from `children` comes first, and what it is
  // given now comes after.
  const content = builder.content
  const all = content === undefined
    ? given
    : given.length === 0
    ? content
    : children([...content, ...given])
  const hooks = builder.hooks
  return hooks === undefined
    ? elementOf(builder, all)
    : forwardTo(builder, hooks, all)
}

const elementOf = <Msg, R>(
  builder: ElementBuilder<Msg, any, any, any>,
  children: ReadonlyArray<Node<Msg, any>>
): Element<Msg, R> => ({
  _tag: "Element",
  tag: builder.tag,
  elementKey: builder.elementKey,
  attrs: builder.owned.length === 0
    ? builder.elementAttrs
    : withTokens(builder.elementAttrs, builder.owned),
  props: builder.props,
  handlers: builder.handlers,
  eventOptions: builder.eventOptions,
  refKey: builder.refKey,
  mount: builder.mount,
  owned: builder.owned,
  children
})

/**
 * What a builder's `forward` stores: a function from the finished builder
 * to the element to render.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type Forward = (
  node: any
) => Element<any, any> | ElementBuilder<any, any, any, any>

// Builds a builder that holds hooks. The last hook set runs first. It gets
// the finished builder: this one without that hook and without its key,
// holding every child. Building that runs the hooks set before it. The key
// goes on what the hook returns, as siblings are matched by the outermost
// node.
const forwardTo = <Msg, R>(
  builder: ElementBuilder<Msg, any, any, any>,
  hooks: ReadonlyArray<Forward>,
  content: ReadonlyArray<Node<Msg, any>>
): Element<Msg, R> => {
  const finished = copyBuilder(builder) as Mutable<
    ElementBuilder<Msg, any, any, any>
  >
  finished.hooks = hooks.length === 1 ? undefined : hooks.slice(0, -1)
  finished.content = content
  finished.elementKey = undefined
  const out: Node<Msg, R> = toNode(hooks[hooks.length - 1]!(finished))
  if (out._tag !== "Element") {
    throw new Error(
      `forward: the <${builder.tag}> was built into a ${out._tag}, and its hook has to return an element`
    )
  }
  return builder.elementKey === undefined
    ? out
    : { ...out, elementKey: builder.elementKey }
}

/**
 * A copy of `builder` with `place` added after the hooks it already holds.
 * What a builder's `forward` calls.
 *
 * @internal
 */
export const withForward = <B extends ElementBuilder<any, any, any, any>>(
  builder: B,
  place: Forward
): B => {
  const out = copyBuilder(builder) as Mutable<B>
  out.hooks = builder.hooks === undefined ? [place] : [...builder.hooks, place]
  return out
}

/**
 * A copy of `builder` with `inputs` after the children it already holds,
 * normalised as `children` does. What a builder's `children` calls, with
 * its rest arguments: the array is reused for the first children.
 *
 * @stability experimental
 * @category vocabularies
 * @since 0.1.0
 */
export const withContent = <B extends ElementBuilder<any, any, any, any>>(
  builder: B,
  inputs: ReadonlyArray<Input<any, any>>
): B => {
  const out = copyBuilder(builder) as Mutable<B>
  const content = builder.content
  out.content = content === undefined
    ? (inputs.length === 0
      ? noChildren
      : childrenOf(inputs as Array<Input<any, any>>))
    : inputs.length === 0
    ? content
    : children([...content, ...inputs])
  return out
}

/**
 * Like {@link withContent}, for a container element that cannot hold text
 * directly. Throws if any child is text and marks slot `Outlet` nodes so
 * the runtime rejects text passed through them. `vocabulary` is the
 * vocabulary of `builder`: the error names it, and its `textParents` as
 * where text goes.
 *
 * @stability experimental
 * @category vocabularies
 * @since 0.1.0
 */
export const withNoTextContent = <B extends ElementBuilder<any, any, any, any>>(
  builder: B,
  inputs: ReadonlyArray<Input<any, any>>,
  vocabulary: Pick<Vocabulary, "name" | "textParents">
): B => {
  const out = withContent(builder, inputs) as Mutable<B>
  let message: string | undefined
  let updated: Array<Node<any, any>> | undefined
  const content = out.content ?? noChildren
  for (let index = 0; index < content.length; index++) {
    const child = content[index]!
    if (child._tag === "Text") {
      throw new Error(noTextMessage(builder.tag, vocabulary))
    }
    if (child._tag === "Outlet") {
      updated ??= [...content]
      updated[index] = {
        _tag: "Outlet",
        name: child.name,
        noText: message ??= noTextMessage(builder.tag, vocabulary)
      }
    }
  }
  if (updated !== undefined) out.content = updated
  return out
}

const noTextMessage = (
  tag: string,
  vocabulary: Pick<Vocabulary, "name" | "textParents">
): string =>
  `<${tag}> can't hold text in the ${vocabulary.name} vocabulary; text goes inside ${
    (vocabulary.textParents ?? []).join(", ")
  }`

/**
 * `children`, for an array the caller owns, such as a method's rest
 * arguments. While the inputs are nodes, builders and text that stands
 * alone, each is turned into its node where it is, and the array itself is
 * the result: no second array, and none with room to spare. The first input
 * that needs more, a hole, a nested array or text to join, hands what's left
 * to `children`.
 */
const childrenOf = <Msg>(
  inputs: Array<Input<Msg, any>>
): Array<Node<Msg, any>> => {
  let afterText = false
  for (let i = 0; i < inputs.length; i++) {
    const input = inputs[i]
    if (typeof input === "string") {
      if (input === "" || afterText) return children(inputs)
      inputs[i] = text(input)
      afterText = true
    } else if (
      input === false || input === null || input === undefined ||
      Array.isArray(input)
    ) {
      return children(inputs)
    } else {
      const node: Node<Msg, any> = toNode(input as Content<Msg, any>)
      if (node._tag === "Text") {
        if (node.text === "" || afterText) return children(inputs)
        afterText = true
      } else {
        afterText = false
      }
      inputs[i] = node
    }
  }
  return inputs as Array<Node<Msg, any>>
}

const withTokens = (
  attrs: Readonly<Record<string, string>>,
  owned: ReadonlyArray<Owned>
): Readonly<Record<string, string>> => {
  let out: Record<string, string> | undefined
  for (let index = 0; index < owned.length; index++) {
    const tokens = owned[index]!.tokens
    if (tokens === noFields) continue
    for (const name in tokens) {
      out ??= { ...attrs }
      out[name] = joinTokens(out[name], tokens[name]!)
    }
  }
  return out ?? attrs
}

const joinTokens = (current: string | undefined, added: string): string => {
  const tokens = current === undefined
    ? []
    : current.split(/\s+/).filter((token) => token !== "")
  for (const token of added.split(/\s+/)) {
    if (token !== "" && !tokens.includes(token)) tokens.push(token)
  }
  return tokens.join(" ")
}

/**
 * Copies a builder with some of its fields replaced, keeping its class. Every
 * chain method is written with it, so a builder stays a value.
 *
 * @stability experimental
 * @category constructors
 * @since 0.1.0
 */
export const withFields = <B extends ElementBuilder<any, any, any, any>>(
  builder: B,
  fields: Partial<
    Pick<
      ElementBuilder<unknown>,
      | "elementKey"
      | "elementAttrs"
      | "props"
      | "handlers"
      | "eventOptions"
      | "refKey"
      | "mount"
      | "owned"
    >
  >
): B => Object.assign(copyBuilder(builder), fields)

/**
 * A copy of a builder, with its class and every field it holds.
 *
 * A view copies a builder for each chain call, so the copy is what building a
 * view costs most. A builder that holds only the base class's fields is
 * copied by a constructor made for its class, which stores them one by one:
 * several times faster than a generic copy. A builder that holds another
 * field under a string key, from its class or added to it, is copied
 * generically. A field under a symbol isn't looked for, as asking for a
 * builder's symbols on every copy cost about as much as the rest of
 * building a view, so a copy leaves it behind.
 */
const copyBuilder = <B extends ElementBuilder<any, any, any, any>>(
  builder: B
): B => {
  // Counted in place: `Object.keys` would make an array for every copy.
  let fields = 0
  for (const _ in builder) fields++
  // A builder keeps no state under a symbol, so the count is the whole check.
  if (fields === builderFields.length) {
    const proto = Object.getPrototypeOf(builder)
    let copier = proto === lastProto ? lastCopier : copiers.get(proto)
    if (copier === undefined) {
      copiers.set(proto, copier = makeCopier(proto, builder))
    }
    lastProto = proto
    lastCopier = copier
    if (copier !== null) return new copier(builder) as B
  }
  return Object.assign(Object.create(Object.getPrototypeOf(builder)), builder)
}

const builderFields = [
  "elementKey",
  "elementAttrs",
  "props",
  "handlers",
  "eventOptions",
  "refKey",
  "mount",
  "owned",
  "content",
  "hooks",
  "removals",
  "tag"
] as const

type Copier = new(
  builder: ElementBuilder<any, any, any, any>
) => ElementBuilder<any, any, any, any>

/** A class's copier by its prototype, or `null` for a class whose builders are copied generically. */
const copiers = new WeakMap<object, Copier | null>()
let lastProto: object | undefined
let lastCopier: Copier | null = null

/**
 * A constructor that copies the base fields of a builder of the class with
 * `proto`. `null` when `first`, the first builder of the class to be copied,
 * lacks a base field, which a count of its keys doesn't show.
 */
const makeCopier = (
  proto: object,
  first: ElementBuilder<any, any, any, any>
): Copier | null => {
  for (const field of builderFields) {
    if (!Object.hasOwn(first, field)) return null
  }
  const copier = function(
    this: Mutable<ElementBuilder<any, any, any, any>>,
    from: ElementBuilder<any, any, any, any>
  ) {
    this.elementKey = from.elementKey
    this.elementAttrs = from.elementAttrs
    this.props = from.props
    this.handlers = from.handlers
    this.eventOptions = from.eventOptions
    this.refKey = from.refKey
    this.mount = from.mount
    this.owned = from.owned
    this.content = from.content
    this.hooks = from.hooks
    this.removals = from.removals
    this.tag = from.tag
  }
  copier.prototype = proto
  return copier as unknown as Copier
}

/**
 * A part of a headless component: it takes the builder of an element the
 * consumer wrote and returns it with the part's attributes, properties and
 * owned layer added.
 *
 * **Details**
 *
 * `Tag` is the tag, or the union of tags, the part is declared for, and
 * `string` for a part that takes any element. `Args` is what the part takes
 * after the builder, and `R` what its mount requires, which joins the
 * headless component's requirements.
 *
 * A part is tied to tag names, the same check the runtime makes: a part
 * declared for `"h2"` takes `h.h2` and rejects `h.h3`, although both
 * render an `HTMLHeadingElement`. A part that takes several tags lists them,
 * as `p.part(["h2", "h3"], ...)`.
 *
 * The result is the builder's chain type, never the callable root, so
 * `menu.trigger(h.button)("Open")` doesn't compile.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface Part<
  in out Tag extends string,
  in Args extends ReadonlyArray<any>,
  out R = never
> {
  <B extends PartTarget<Tag>>(builder: B, ...args: Args): ReturnType<B["attr"]>
  readonly "~R"?: (_: never) => R
}

/**
 * What a part accepts: a builder whose declared tag is one of `Tag`, either
 * a tag's callable root or its chain type.
 *
 * **Details**
 *
 * It's structural on purpose. With `ElementBuilder` as the constraint, a
 * callable root such as `h.dialog` infers as the constraint and loses its
 * chain type. A builder whose tag isn't known, such as `h.el("x-foo")`'s,
 * only fits a part declared without a tag.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface PartTarget<out Tag extends string> {
  readonly "~Tag"?: Tag | undefined
  readonly attr: (...args: any) => any
}

/**
 * The requirements of the parts in a headless component's `parts` record.
 *
 * @stability experimental
 * @category utility types
 * @since 0.1.0
 */
export type PartRequirements<P> = P extends
  { readonly "~R"?: (_: never) => infer R } ? R : never

/**
 * Keeps a part's requirements on a wrapper function returned from a headless
 * component's `parts`.
 *
 * **Details**
 *
 * Returns `wrapper` unchanged, preserving its parameters, generics and return
 * type. Use it when adapting a part to an options object or adding markup.
 * The wrapper must apply `part`; this only carries that part's requirements,
 * not requirements of any other parts or effects the wrapper uses.
 *
 * **Example** (A part with an options object)
 *
 * ```ts import.meta.vitest
 * import { View } from "@effect/ui"
 *
 * const withOptions = <R>(part: View.Part<"button", [], R>) =>
 *   View.wrapPart(part, <B extends View.PartTarget<"button">>(
 *     { element }: { element: B }
 *   ): ReturnType<B["attr"]> => part(element))
 * ```
 *
 * @stability experimental
 * @category constructors
 * @since 0.1.0
 */
export const wrapPart = <
  P extends { readonly "~R"?: (_: never) => unknown },
  F extends (...args: Array<any>) => any
>(_part: P, wrapper: F): F & Pick<P, "~R"> => wrapper

/**
 * Makes a part for one owner. `decorate` gets an empty builder of the
 * consumer's class and tag, so it never sees what the consumer set. Its
 * attributes and properties are written over the consumer's, except token
 * lists, and its handlers, event options, ref, mount and token lists become
 * one owned layer. The children it adds go after the ones the consumer's
 * builder holds, and what it sets with `forward` after the builder's.
 *
 * @internal
 */
export const makePart = (
  owner: Owner,
  tags: ReadonlyArray<string> | undefined,
  decorate: (
    builder: any,
    ...args: ReadonlyArray<any>
  ) => ElementBuilder<any, any, any, any>
): Part<any, any, any> =>
(target: PartTarget<any>, ...args: ReadonlyArray<any>): any => {
  const builder: unknown = target
  if (!(builder instanceof ElementBuilder)) {
    throw new Error(
      owner.path + ": a part takes an element builder, such as h.button"
    )
  }
  if (tags !== undefined && !tags.includes(builder.tag)) {
    throw new Error(
      owner.path + ": a part for <" + tags.join("> or <") + "> was given <" +
        builder.tag + ">"
    )
  }
  const blank: ElementBuilder<any, any, any, any> = Object.assign(
    Object.create(Object.getPrototypeOf(builder)),
    blankFields,
    { tag: builder.tag, removals: [] }
  )
  const patch = decorate(blank, ...args)
  if (!(patch instanceof ElementBuilder)) {
    throw new Error(owner.path + ": a part returns the builder it was given")
  }
  if (patch.elementKey !== undefined) {
    throw new Error(owner.path + ": a part can't set an element's key")
  }
  if (patch.owned.length > 0) {
    throw new Error(owner.path + ": a part can't apply another part")
  }
  const attrs: Record<string, string> = { ...builder.elementAttrs }
  let tokens: Record<string, string> | undefined
  for (const name of patch.removals ?? []) {
    // Token lists are additive: a part can omit its own tokens, not the consumer's.
    if (!tokenListAttributes.has(name)) delete attrs[name]
  }
  for (const name in patch.elementAttrs) {
    if (tokenListAttributes.has(name)) {
      ;(tokens ??= {})[name] = patch.elementAttrs[name]!
    } else attrs[name] = patch.elementAttrs[name]!
  }
  const layer: Owned = {
    owner,
    handlers: patch.handlers,
    eventOptions: patch.eventOptions,
    refKey: patch.refKey,
    mount: patch.mount,
    tokens: tokens ?? noFields
  }
  const out = withFields(builder, {
    elementAttrs: attrs,
    props: patch.props === noFields
      ? builder.props
      : builder.props === noFields
      ? patch.props
      : { ...builder.props, ...patch.props },
    owned: [...builder.owned, layer]
  })
  // The part's children come after the ones the builder came with, and its
  // hooks are set after the builder's.
  if (patch.content !== undefined) {
    ;(out as Mutable<typeof out>).content = builder.content === undefined
      ? patch.content
      : children([...builder.content, ...patch.content])
  }
  if (patch.hooks !== undefined) {
    ;(out as Mutable<typeof out>).hooks = builder.hooks === undefined
      ? patch.hooks
      : [...builder.hooks, ...patch.hooks]
  }
  return out
}

/**
 * `record` with `name` set to `value` as its last entry, or without `name`
 * when `value` is `undefined`.
 */
const withEntry = <A>(
  record: Readonly<Record<string, A>>,
  name: string,
  value: A | undefined
): Readonly<Record<string, A>> => {
  if (!Object.hasOwn(record, name)) {
    return value === undefined
      ? record
      : assoc(record, name, value)
  }
  const out: Record<string, A> = {}
  for (const key in record) {
    if (key !== name) put(out, key, record[key]!)
  }
  if (value !== undefined) put(out, name, value)
  return out
}

/**
 * `{ ...record, [name]: value }`, written as a copy and a store: an object
 * literal with a computed key is several times slower.
 */
const assoc = <A>(
  record: Readonly<Record<string, A>>,
  name: string,
  value: A
): Readonly<Record<string, A>> => {
  // The first entry of most records: nothing to copy.
  if (record === noFields) return firstEntry(name, value)
  const out: Record<string, A> = { ...record }
  put(out, name, value)
  return out
}

/**
 * A record holding one entry. The names set most often are written as literals, which hold their
 * one entry in place, where `{}` keeps room for four. A literal is also faster to build than a
 * store under a name a view chose.
 */
const firstEntry = <A>(name: string, value: A): Record<string, A> => {
  switch (name) {
    case "class":
      return { class: value }
    case "id":
      return { id: value }
    case "click":
      return { click: value }
    case "input":
      return { input: value }
  }
  const out: Record<string, A> = {}
  put(out, name, value)
  return out
}

/** Sets an own entry, `__proto__` included, which a plain store would take as the prototype. */
const put = <A>(record: Record<string, A>, name: string, value: A): void => {
  if (name === "__proto__") {
    Object.defineProperty(record, name, {
      value,
      writable: true,
      enumerable: true,
      configurable: true
    })
  } else {
    record[name] = value
  }
}

type Mutable<A> = { -readonly [K in keyof A]: A[K] }

const blankFields = {
  elementKey: undefined,
  elementAttrs: noFields,
  props: noFields,
  handlers: noFields,
  eventOptions: noFields,
  refKey: undefined,
  mount: undefined,
  owned: noOwned,
  content: undefined,
  hooks: undefined,
  removals: undefined
}

let lastPath = ""
let lastEscaped = ""

/**
 * An id for an element of the instance at `path`, the same on the server and
 * the client. The path, the name and the key are each escaped down to
 * `[A-Za-z0-9]` and joined with a hyphen, which no escaped field contains:
 * two ids are equal only when all three are. The result is safe in a
 * space-separated list such as `aria-labelledby`, and in a selector.
 *
 * @internal
 */
export const idOf = (
  path: string,
  name: string,
  key?: string | number | undefined
): string => {
  if (path !== lastPath) {
    lastPath = path
    lastEscaped = escapeId(path)
  }
  return lastEscaped + "-" + escapeId(name) +
    (key === undefined ? "" : "-" + escapeId(String(key)))
}

// The underscore that opens and closes an escape is escaped too, so the escaping can be undone.
const escapeId = (value: string): string =>
  value.replace(
    /[^A-Za-z0-9]/g,
    (char) => "_" + char.codePointAt(0)!.toString(36) + "_"
  )

/**
 * The element builder: `h.el(tag)` and a vocabulary's element names. It
 * holds attributes, properties, handlers, a key, a ref, a mount and the
 * children given so far.
 *
 * **Details**
 *
 * Every method returns a copy, so a view stays a value. `Handlers` maps an
 * event name to its payload; a vocabulary's element class fixes it and adds
 * its own helpers. The core builder leaves payloads untyped.
 *
 * This base class has no `children`, so it's the shape of a void element.
 * `ContainerBuilder` adds it, and a vocabulary does the same for the tags
 * that take children. A builder is itself valid content: as a child or a
 * view it renders as its element with no children.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export class ElementBuilder<
  out Msg,
  out R = never,
  in out Handlers = Record<string, unknown>,
  in out HostNode = unknown,
  out Tag extends string = string
> {
  /**
   * The key set with `key`, if any.
   *
   * @since 0.1.0
   */
  readonly elementKey: string | undefined = undefined
  /**
   * The attributes set with `attr` or `attrs`.
   *
   * @since 0.1.0
   */
  readonly elementAttrs: Readonly<Record<string, string>> = noFields
  /**
   * The properties set with `prop`.
   *
   * @since 0.1.0
   */
  readonly props: Readonly<Record<string, unknown>> = noFields
  /**
   * The handlers set with `on`, by event name.
   *
   * @since 0.1.0
   */
  readonly handlers: Readonly<Record<string, Handler<Msg, any>>> = noFields
  /**
   * The options set with `on`, by event name.
   *
   * @since 0.1.0
   */
  readonly eventOptions: Readonly<Record<string, EventOptions>> = noFields
  /**
   * The ref set with `ref`, if any.
   *
   * @since 0.1.0
   */
  readonly refKey: string | undefined = undefined
  /**
   * The work set with `onMount`, if any.
   *
   * @since 0.1.0
   */
  readonly mount: Mount<Msg> | undefined = undefined
  /**
   * The layers added by the parts of headless components.
   *
   * @since 0.1.0
   */
  readonly owned: ReadonlyArray<Owned> = noOwned
  /**
   * The children given with `children` so far, as nodes, or `undefined`
   * before the first call. Read the element's children off the node,
   * `View.build(builder, []).children`, which also runs `forward`.
   *
   * @since 0.1.0
   */
  readonly content: ReadonlyArray<Node<Msg, any>> | undefined = undefined
  /**
   * The functions set with `forward`, in the order they were set.
   *
   * @since 0.1.0
   */
  readonly hooks: ReadonlyArray<Forward> | undefined = undefined
  /**
   * On the blank builder a part decorates, the attributes the part
   * removed. `undefined` on every other builder.
   *
   * @since 0.1.0
   */
  readonly removals: ReadonlyArray<string> | undefined = undefined
  /**
   * Phantom: the requirements of the element's mount, which surface in the
   * component's.
   *
   * @since 0.1.0
   */
  declare readonly "~R"?: (_: never) => R
  /**
   * Phantom: the host node this element renders to, which types `ref` and
   * `onMount`.
   *
   * @since 0.1.0
   */
  declare readonly "~HostNode"?: (_: HostNode) => HostNode
  /**
   * Phantom: the element's events and their payloads.
   *
   * @since 0.1.0
   */
  declare readonly "~Handlers"?: Handlers
  /**
   * Phantom: the element's tag as the vocabulary declares it, which a part
   * of a headless component checks. `string` when it isn't known, as for
   * `h.el`.
   *
   * @since 0.1.0
   */
  declare readonly "~Tag"?: Tag
  /**
   * The element's tag.
   *
   * @since 0.1.0
   */
  readonly tag: string
  constructor(tag: string) {
    this.tag = tag
  }
  /**
   * Sends a message when `event` fires: a value, or a function of the payload.
   * `options` sets how the host treats the event, such as `preventDefault`.
   * Setting `event` again replaces its handler and its options.
   *
   * @since 0.1.0
   */
  on<K extends keyof Handlers & string>(
    event: K,
    handler: Handler<Msg, Handlers[K]>,
    options?: EventOptions | undefined
  ): this {
    const out = copyBuilder(this) as Mutable<this>
    out.handlers = assoc(this.handlers, event, handler)
    const eventOptions = this.eventOptions
    if (eventOptions === noFields) {
      if (options !== undefined) {
        out.eventOptions = assoc(eventOptions, event, options)
      }
    } else if (options !== undefined || Object.hasOwn(eventOptions, event)) {
      out.eventOptions = withEntry(eventOptions, event, options)
    }
    return out
  }
  /**
   * Keeps this element's node when its siblings move. Unique among siblings.
   *
   * @since 0.1.0
   */
  key(key: string): this {
    const out = copyBuilder(this) as Mutable<this>
    out.elementKey = key
    return out
  }
  /**
   * Sets an attribute, or removes it with `undefined`.
   *
   * @since 0.1.0
   */
  attr(name: string, value: string | undefined): this {
    const attrs = this.elementAttrs
    const removals = this.removals
    // A `shorthand` is a function whose chain methods must return a plain builder.
    if (
      value === undefined && removals === undefined &&
      (attrs === noFields || !Object.hasOwn(attrs, name)) &&
      typeof this !== "function"
    ) return this
    const out = copyBuilder(this) as Mutable<this>
    if (value === undefined && removals !== undefined) {
      out.removals = [...removals, name]
    }
    if (attrs === noFields) {
      if (value !== undefined) out.elementAttrs = assoc(attrs, name, value)
      // Removing an attribute that isn't set leaves the record as it is.
    } else if (value !== undefined || Object.hasOwn(attrs, name)) {
      out.elementAttrs = withEntry(attrs, name, value)
    }
    return out
  }
  /**
   * Sets multiple attributes, removing any whose value is `undefined`.
   *
   * @since 0.1.0
   */
  attrs(attributes: Readonly<Record<string, string | undefined>>): this {
    if (this.attr !== ElementBuilder.prototype.attr) {
      let out: this | undefined
      for (const name in attributes) {
        if (Object.hasOwn(attributes, name)) {
          out = (out ?? this).attr(name, attributes[name])
        }
      }
      return out ?? copyBuilder(this)
    }
    const out = copyBuilder(this) as Mutable<this>
    const current = this.elementAttrs
    let removals: Array<string> | undefined
    let next: Record<string, string> | undefined
    for (const name in attributes) {
      if (!Object.hasOwn(attributes, name)) continue
      const value = attributes[name]
      if (value === undefined) {
        if (this.removals !== undefined) {
          removals ??= this.removals.slice()
          removals.push(name)
        }
        if (current !== noFields && Object.hasOwn(next ?? current, name)) {
          next ??= { ...current }
          delete next[name]
        }
      } else {
        next ??= current === noFields ? {} : { ...current }
        if (Object.hasOwn(next, name)) delete next[name]
        put(next, name, value)
      }
    }
    if (removals !== undefined) out.removals = removals
    if (next !== undefined) out.elementAttrs = next
    return out
  }
  /**
   * Sets a property. The host decides what it means.
   *
   * @since 0.1.0
   */
  prop(name: string, value: unknown): this {
    const out = copyBuilder(this) as Mutable<this>
    out.props = assoc(this.props, name, value)
    return out
  }
  /**
   * Names this element for ref Commands, which reach it through
   * `Renderer.Refs` within the instance that renders it. A ref declared for
   * another kind of node doesn't compile.
   *
   * @since 0.1.0
   */
  ref(ref: Renderer.Ref<HostNode>): this {
    const out = copyBuilder(this) as Mutable<this>
    out.refKey = ref.key
    return out
  }
  /**
   * Starts `mount` with this element's host node after it's committed, in a
   * Scope that closes when the element goes and survives patches. A message
   * it ends with comes back to the component, and one that ends with
   * `Component.noop` sends nothing and logs no `Update`. Its requirements
   * join the component's.
   *
   * **Details**
   *
   * `mount` is an issued mount: a definition from `Mount.make` called with
   * its args, and mapped to the component's message with `Mount.map` when
   * its result isn't one. A mount whose body needs another kind of host node
   * than this element's doesn't compile.
   *
   * The body runs once per element. A later render's args reach it through
   * its `changes` Stream, when they differ by the args Schema's equivalence.
   * A render that gives the element a mount of another definition stops the
   * running one and starts the new one, and a render without a mount stops
   * it.
   *
   * A defect fails the instance. It never runs on the server or on a host that
   * doesn't run mounts, such as `TestHost`, where a test sends the message
   * itself. A vocabulary's element class overrides it to return its own
   * class, so the chain goes on after it.
   *
   * **Gotchas**
   *
   * An element takes one mount: calling `onMount` again throws. A mount from
   * `Mount.make` ends with one message. One that sends messages as it goes,
   * such as a widget's events, is defined with `Mount.makeStream`.
   *
   * A body that is an `Effect<void>` doesn't compile here, because a `void`
   * type can hold any value, which would be sent as a message. When there is
   * nothing to report, use `Effect.as(Component.noop)`. This sends no message;
   * the log records the body's completion as `MountEnded` with `silent: true`.
   *
   * @since 0.1.0
   */
  onMount<R2>(
    mount: MountModule.Issued<Msg | Component.Noop, R2, HostNode, never>
  ): ElementBuilder<Msg, R | R2, Handlers, HostNode, Tag>
  /**
   * Rejects any other mount result, with a type error that says what to end
   * it with.
   *
   * @since 0.1.0
   */
  onMount(
    mount: MountModule.Issued<
      Msg | Component.Noop | MountHint,
      any,
      HostNode,
      never
    >
  ): never
  onMount(mount: Mount<Msg>): any {
    if (this.mount !== undefined) {
      throw new Error(
        `onMount(${mount.name}): this element already has the mount ${this.mount.name}, and an element takes one`
      )
    }
    return withFields(this, { mount })
  }
  /**
   * Lets a chain land on an element that sits below the root of what is
   * rendered. `place` gets the finished element, with everything chained
   * after this call and its children in it, and returns the element to
   * render: one around it, or the finished element itself.
   *
   * **When to use**
   *
   * Use when a function takes a builder and returns it, and the element
   * needs markup around it, or the function's own attributes written after
   * the caller's.
   *
   * **Details**
   *
   * `place` runs when the builder becomes an element: as another element's
   * child, or as what a view returns. What it returns has to be an
   * element, and the requirements of what it adds join this element's.
   *
   * The finished element is still a builder. `place` can read what the
   * caller chained, such as `node.handlers`, and write attributes after
   * it. Children it adds come after the caller's.
   *
   * A key set on the builder, before or after this call, goes on the
   * element `place` returns, as siblings are matched by their outermost
   * node. The ref, the mount and the handlers stay on the finished element.
   *
   * A builder can hold several of these functions, from this method and
   * from the parts applied to it. The last one set runs first, and building
   * the finished element it gets runs the one before. So the last call's
   * markup is outermost, and the first call writes its attributes last.
   *
   * **Example** (A frame around the caller's input)
   *
   * ```ts import.meta.vitest
   * import { View } from "@effect/ui"
   * import { Html } from "@effect/ui/html"
   *
   * const h = View.makeHelper<never, {}, Html.Elements>({}, Html)
   *
   * // The class and the attribute land on the input, inside the frame.
   * const framed = h.input.forward((node) => h.div.class("frame").children(node))
   * const frame = View.build(framed.class("amount").attr("inputmode", "decimal"), [])
   *
   * if (frame.tag !== "div" || frame.attrs.class !== "frame") throw new Error("the frame isn't outermost")
   * ```
   *
   * @since 0.1.0
   */
  forward<R2 = never>(
    place: (
      node: ElementBuilder<Msg, R, Handlers, HostNode, Tag>
    ) => Element<Msg, R2> | ElementBuilder<Msg, R2, any, any>
  ): ElementBuilder<Msg, R | R2, Handlers, HostNode, Tag> {
    return withForward(this, place) as any
  }
}

/**
 * The builder of an element that takes children: what `h.el` returns.
 *
 * **Details**
 *
 * `children` returns the builder with the children added after the ones it
 * holds. So a function that takes a builder can add children of its own and
 * still return a builder, for its caller to add more.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export class ContainerBuilder<
  out Msg,
  out R = never,
  in out Handlers = Record<string, unknown>,
  in out HostNode = unknown,
  out Tag extends string = string
> extends ElementBuilder<Msg, R, Handlers, HostNode, Tag> {
  /**
   * Like `ElementBuilder.onMount`, keeping `children`.
   *
   * @since 0.1.0
   */
  override onMount<R2>(
    mount: MountModule.Issued<Msg | Component.Noop, R2, HostNode, never>
  ): ContainerBuilder<Msg, R | R2, Handlers, HostNode, Tag>
  /**
   * Rejects any other mount result, with a type error that says what to end
   * it with.
   *
   * @since 0.1.0
   */
  override onMount(
    mount: MountModule.Issued<
      Msg | Component.Noop | MountHint,
      any,
      HostNode,
      never
    >
  ): never
  override onMount(mount: Mount<Msg>): any {
    return (super.onMount as any)(mount)
  }
  /**
   * Adds children after the ones the builder holds, and returns the
   * builder: nodes, builders, text, arrays to flatten, and holes (`false`,
   * `null`, `undefined`). Their requirements join the element's.
   *
   * @since 0.1.0
   */
  children<const C extends ReadonlyArray<Input<Msg, any>>>(
    ...inputs: C
  ): ContainerBuilder<
    Msg,
    R | Requirements<C[number]>,
    Handlers,
    HostNode,
    Tag
  > {
    return withContent(this, inputs) as any
  }
  /**
   * Like `ElementBuilder.forward`, keeping `children`.
   *
   * @since 0.1.0
   */
  override forward<R2 = never>(
    place: (
      node: ContainerBuilder<Msg, R, Handlers, HostNode, Tag>
    ) => Element<Msg, R2> | ElementBuilder<Msg, R2, any, any>
  ): ContainerBuilder<Msg, R | R2, Handlers, HostNode, Tag> {
    return withForward(this, place) as any
  }
}

/**
 * A root builder that is also callable: `b(...inputs)` is
 * `b.children(...inputs)`. What a vocabulary puts on `h` for a tag that
 * takes children, such as `h.button("Add")`.
 *
 * **Details**
 *
 * The chain methods and the call return the builder `B`, which isn't
 * callable: `h.div(a).children(b)` adds `b`, and `h.div(a)(b)` doesn't
 * compile.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export type Shorthand<
  B extends { readonly children: (...inputs: any) => any }
> = Omit<B, never> & B["children"]

/**
 * Makes a builder callable as `Shorthand` describes, for a vocabulary's
 * `tags`. Make one per tag, once: `h` shares it across renders.
 *
 * **Details**
 *
 * The result is a function with the builder's class and fields. Its chain
 * methods copy only the builder's fields, so the function's own `name` and
 * `length` never reach a node.
 *
 * @stability experimental
 * @category vocabularies
 * @since 0.1.0
 */
export const shorthand = <
  B extends ElementBuilder<any, any, any, any> & {
    readonly children: (...inputs: any) => any
  }
>(
  builder: B
): Shorthand<B> => {
  const root = (...inputs: ReadonlyArray<Input<any, any>>) =>
    (root as any).children(...inputs)
  Object.setPrototypeOf(root, Object.getPrototypeOf(builder))
  return Object.assign(root, builder) as any
}

/**
 * A type-level function from a message type to a set of element constructors,
 * which a vocabulary implements.
 *
 * **Details**
 *
 * `Tags` is read with `Msg` bound: `(V & { Msg })["Tags"]`. `Host` is the
 * service a host's Layer provides to say it can show these elements, which
 * `mount` requires for the root.
 *
 * `Head` is the entry type a component's `head` returns, and `HeadValue`
 * the value the vocabulary's merge folds them into.
 * A vocabulary that declares neither has `Head`'s host-neutral title
 * entries. Read them with `HeadEntry` and `HeadValue`.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface Elements {
  readonly Msg: unknown
  readonly Tags: unknown
  readonly Host: unknown
  readonly Head?: unknown
  readonly HeadValue?: unknown
}

/**
 * The entries a component of vocabulary `V` may return from `head`: the
 * vocabulary's `Head`, or `Head.Entry` when `V` is `never` or declares none.
 *
 * @stability experimental
 * @category utility types
 * @since 0.1.0
 */
export type HeadEntry<V> = [V] extends [never] ? Head.Entry
  : V extends { readonly Head: infer E } ? E
  : Head.Entry

/**
 * The folded head of vocabulary `V`: the vocabulary's `HeadValue`, or
 * `Head.Head` when `V` is `never` or declares none.
 *
 * @stability experimental
 * @category utility types
 * @since 0.1.0
 */
export type HeadValue<V> = [V] extends [never] ? Head.Head
  : V extends { readonly HeadValue: infer H } ? H
  : Head.Head

/**
 * How a vocabulary folds its head: `merge` folds a tree of entries into the
 * vocabulary's value, reporting conflicts, and `title` reads the title out of
 * that value for the Router's announcement.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface HeadFold<E = any, H = any> {
  readonly merge: (tree: Head.Tree<E>, options?: Head.MergeOptions) => H
  readonly title: (head: H) => string | undefined
}

/**
 * The runtime half of a vocabulary: its root element builders, installed on
 * `h` and shared by every render.
 *
 * **Details**
 *
 * A tag that takes children is a `shorthand` builder, so `h.span(title)`
 * works; a void tag is a plain builder.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface Vocabulary<out V extends Elements = Elements> {
  readonly name: string
  readonly tags: Readonly<Record<string, ElementBuilder<any, any, any, any>>>
  /**
   * The only tags that may hold text, for a vocabulary such as a native one
   * where text lives in a text primitive. `h.el` checks it at runtime. Text
   * goes anywhere when it's left out.
   */
  readonly textParents?: ReadonlyArray<string> | undefined
  /**
   * How the vocabulary folds its head, when the root of a mount is of this
   * vocabulary. Without it, `Head.merge` folds the title only.
   */
  readonly head?: HeadFold | undefined
  /**
   * Phantom: the type-level half of the vocabulary. A vocabulary written as a
   * module, such as `Html`, exports it as an `undefined` value, so the module
   * namespace itself is a `Vocabulary`.
   */
  readonly Elements?: V | undefined
}

/**
 * The element names a vocabulary adds to `h`, bound to a component's message
 * type. Nothing when `V` is `never`.
 *
 * @stability experimental
 * @category utility types
 * @since 0.1.0
 */
export type Tags<V, Msg> = [V] extends [never] ? {}
  : V extends Elements ? (V & { readonly Msg: Msg })["Tags"]
  : {}

/**
 * Combines {@link Helper} with a vocabulary's {@link Tags}. When the
 * vocabulary declares its own `text` tag (such as a terminal or native
 * vocabulary), the vocabulary's `text` replaces `Helper.text`.
 *
 * @stability experimental
 * @category utility types
 * @since 0.1.0
 */
export type WithTags<Msg, Props, V> =
  & ("text" extends keyof Tags<V, Msg> ? HelperBase<Msg, Props>
    : Helper<Msg, Props>)
  & Tags<V, Msg>

/**
 * The view helper, `h` in `view`: bound to the component's message type and
 * carrying its props.
 *
 * **Details**
 *
 * The core helper has `el` and `text`. A vocabulary's element names
 * are mixed in by `Component.define`.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface Helper<Msg, Props> extends HelperBase<Msg, Props> {
  /** A text node. The only way to put text in a native view. */
  text(text: string): Text
}

/**
 * The view helper without `text`: what every `h` has, including one whose
 * vocabulary declares its own `text` tag. A function that takes any `h`
 * types it with this.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface HelperBase<Msg, Props> {
  readonly props: Props
  /**
   * Any host element by name, with untyped event payloads. What host-neutral
   * code uses: `h.el("x-foo").attr("a", "b").children(...)`.
   */
  el(tag: string): ContainerBuilder<Msg>
  /** Shorthand for `h.el(tag).children(...children)`, with at least one child. */
  el<
    const C extends readonly [
      Input<Msg, any>,
      ...ReadonlyArray<Input<Msg, any>>
    ]
  >(
    tag: string,
    ...children: C
  ): ContainerBuilder<Msg, Requirements<C[number]>>
  /**
   * Whether this instance has a run of the Command in flight, of the group if
   * a pick of its `group` fields is given: queued, running, awaiting, or
   * stopping until its fiber exits, cleanup included. It ends when the run's
   * message has been delivered, or at fiber exit for a run that sends none.
   * Per instance and view only: `update` can't read it, so what `update`
   * decides on, such as ignoring a submit while saving, belongs in the Model.
   */
  isRunning<Args, G extends string>(
    command: Command.Definition<Args, any, boolean, any, G>,
    ...group: Command.GroupArg<Args, G>
  ): boolean
  /**
   * An id for an element of this instance, derived from the instance's path:
   * the same on the server and the client, and different for every instance.
   */
  id(name: string, key?: string | number | undefined): string
  /**
   * The node `fn` builds from `args`, built again only when an argument
   * changes. `fn` gets this helper first, then `args`.
   *
   * **Details**
   *
   * The arguments are compared with `===` to the ones of the last render's
   * call with the same `fn` and first argument. When they're the same, `fn`
   * isn't called and the last node is used again. When that node holds only
   * elements and text, the runtime skips its patch and only sets its
   * controlled properties again, such as an input's `value`.
   *
   * `fn` must depend only on its arguments: what it reads from the helper,
   * such as `h.isRunning`, may be out of date. Declare it outside the view,
   * since a new function each render never matches. The first argument tells
   * calls apart, so give each call its own, such as the row it shows. A call
   * whose first argument an earlier call of the same render used is built
   * every render.
   *
   * **Example** (Rows built again only when they change)
   *
   * ```ts
   * import type { Html } from "@effect/ui/html"
   *
   * type Row = { readonly id: number; readonly label: string }
   *
   * const row = <M>(h: Html.H<M>, row: Row, selected: boolean) =>
   *   h.tr.key(String(row.id)).class(selected && "danger").children(row.label)
   *
   * const rows = <M>(h: Html.H<M>, rows: ReadonlyArray<Row>, selected: number) =>
   *   h.tbody.children(rows.map((item) => h.lazy(row, item, item.id === selected)))
   * ```
   */
  lazy<H, A extends ReadonlyArray<unknown>, C extends Content<Msg, any>>(
    this: H,
    fn: (h: H, ...args: A) => C,
    ...args: A
  ): Node<Msg, Requirements<C>>
}

/**
 * What `h.lazy` keeps between one instance's renders: for each first
 * argument, the last call's function, arguments and node.
 *
 * @internal
 */
export class Lazies {
  entries = new Map<unknown, LazyEntry>()
  /** The render the entries were last used in, and how many were. */
  round = 1
  used = 0
  begin(): void {
    this.round++
    this.used = 0
  }
  /** Drops the entries this render didn't use, such as a removed row's. */
  end(): void {
    const entries = this.entries
    const round = this.round
    if (this.used === entries.size) return
    // When most go, the rest move to a new Map: a Map keeps its size after deletes.
    if (this.used * 4 <= entries.size) {
      const kept = new Map<unknown, LazyEntry>()
      for (const [key, entry] of entries) {
        if (entry.round === round) kept.set(key, entry)
      }
      this.entries = kept
      return
    }
    for (const [key, entry] of entries) {
      if (entry.round !== round) entries.delete(key)
    }
  }
}

interface LazyEntry {
  fn: Function
  args: ReadonlyArray<unknown>
  node: Node<any, any>
  round: number
}

/**
 * Where a host keeps what `h.lazy` built between one instance's renders: an
 * object it keeps for the instance, with `lazy` `undefined` at first.
 *
 * @stability experimental
 * @category models
 * @since 0.1.0
 */
export interface LazyStore {
  lazy: unknown
}

const sameArgs = (
  a: ReadonlyArray<unknown>,
  b: ReadonlyArray<unknown>
): boolean => {
  if (a.length !== b.length) return false
  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i]) return false
  }
  return true
}

/**
 * What `h.isRunning` asks: whether the instance has a run of the named Command,
 * of the group key if given.
 *
 * @internal
 */
export type Running = (name: string, groupKey: string | undefined) => boolean

const notRunning: Running = () => false

class HelperImpl<Msg, Props> implements Helper<Msg, Props> {
  readonly props: Props
  readonly elements: Vocabulary<any> | undefined
  readonly runningFn: Running
  /** The instance's path, or the instance, whose path is read only when `id` is called. */
  readonly at: string | PathSource
  readonly store: LazyStore | undefined
  constructor(
    props: Props,
    elements: Vocabulary<any> | undefined,
    running: Running | undefined,
    at: string | PathSource,
    store: LazyStore | undefined
  ) {
    this.props = props
    this.elements = elements
    this.runningFn = running ?? notRunning
    this.at = at
    this.store = store
  }
  lazy(
    this: any,
    fn: (h: any, ...args: Array<any>) => Content<Msg, any>,
    ...args: Array<any>
  ): any {
    const store = this.store
    if (store === undefined) return toNode(fn(this, ...args))
    const lazies = (store.lazy ??= new Lazies()) as Lazies
    const key = args.length === 0 ? fn : args[0]
    const entry = lazies.entries.get(key)
    const round = lazies.round
    if (entry !== undefined && entry.fn === fn && sameArgs(entry.args, args)) {
      if (entry.round !== round) {
        entry.round = round
        lazies.used++
      }
      return entry.node
    }
    const node = toNode(fn(this, ...args))
    // A key an earlier call of this render took stays theirs.
    if (entry !== undefined && entry.round === round) return node
    if (entry === undefined) lazies.entries.set(key, { fn, args, node, round })
    else {
      entry.fn = fn
      entry.args = args
      entry.node = node
      entry.round = round
    }
    lazies.used++
    return node
  }
  keepAlive(this: any, alive: any, content?: any): unknown {
    const s = Object.create(this)
    s["~alive"] = content ? alive : true
    return (content ?? alive)(s)
  }
  isRunning(command: Command.Definition.Any, group?: unknown): boolean {
    return this.runningFn(
      Command.nameOf(command),
      Command.groupKeyOf(command, group)
    )
  }
  id(name: string, key?: string | number | undefined): string {
    const at = this.at
    return idOf(typeof at === "string" ? at : at.path, name, key)
  }
  el(tag: string, ...inputs: ReadonlyArray<Input<Msg, any>>): any {
    const textParents = this.elements?.textParents
    const builder = textParents === undefined || textParents.includes(tag)
      ? new ContainerBuilder<Msg>(tag)
      : new NoTextBuilder<Msg>(tag, this.elements!)
    return inputs.length === 0 ? builder : builder.children(...inputs)
  }
  text(value: string): Text {
    return text(value)
  }
}

/** `h.el` of a tag that can't hold text in the helper's vocabulary. */
class NoTextBuilder<Msg> extends ContainerBuilder<Msg> {
  readonly vocabulary: Vocabulary<any>
  constructor(tag: string, vocabulary: Vocabulary<any>) {
    super(tag)
    this.vocabulary = vocabulary
  }
  override children<const C extends ReadonlyArray<Input<Msg, any>>>(
    ...inputs: C
  ): ContainerBuilder<Msg, Requirements<C[number]>> {
    return withNoTextContent(this, inputs, this.vocabulary) as any
  }
}

const helperClasses = new WeakMap<
  Vocabulary<any>,
  typeof HelperImpl<any, any>
>()
let lastElements: Vocabulary<any> | undefined
let lastHelperClass: typeof HelperImpl<any, any> | undefined

/**
 * What a runtime can give a view in place of its path: something whose
 * `path` is read only when `h.id` is called.
 *
 * @internal
 */
export interface PathSource {
  readonly path: string
}

const lazyPathViews = new WeakSet<object>()

/**
 * Marks `view` as taking a `PathSource` for its path. Only views that
 * `make` builds are marked: a view written or wrapped by hand is given the
 * path as a string, as its type says.
 *
 * @internal
 */
export const readsPathLazily = <F extends object>(view: F): F => {
  lazyPathViews.add(view)
  return view
}

/**
 * Whether `view` takes a `PathSource` for its path.
 *
 * @internal
 */
export const takesPathSource = (view: object): boolean =>
  lazyPathViews.has(view)

/**
 * Builds the view helper for one render, with a vocabulary's element names
 * mixed in when one is given.
 *
 * @internal
 */
export const makeHelper = <Msg, Props, V extends Elements = never>(
  props: Props,
  elements: Vocabulary<V> | undefined,
  running?: Running | undefined,
  path?: string | PathSource | undefined,
  store?: LazyStore | undefined
): WithTags<Msg, Props, V> => {
  if (elements === undefined) {
    return new HelperImpl(props, undefined, running, path ?? "", store) as any
  }
  let Class = elements === lastElements
    ? lastHelperClass
    : helperClasses.get(elements)
  if (Class === undefined) {
    const Made = class extends HelperImpl<any, any> {}
    Object.assign(Made.prototype, elements.tags)
    helperClasses.set(elements, Class = Made)
  }
  lastElements = elements
  lastHelperClass = Class
  return new Class(props, elements, running, path ?? "", store) as any
}

/**
 * The text of a view, with the text of every element concatenated in order.
 * A child contributes the text of what its parent passed for its slots, in
 * the order they were passed, and nothing of its own view.
 *
 * @stability experimental
 * @category queries
 * @since 0.1.0
 */
export const textOf = (node: Node<any, any>): string => {
  switch (node._tag) {
    case "Text":
      return node.text
    case "Element":
      return node.children.map(textOf).join("")
    case "Child":
      return slotNodes(node).map(textOf).join("")
    case "Outlet":
      return ""
  }
}

/**
 * Every node of a view in document order, the root first. A child is
 * followed by what its parent passed for its slots, in the order they were
 * passed.
 *
 * @stability experimental
 * @category queries
 * @since 0.1.0
 */
export const nodes = function*<Msg>(
  node: Node<Msg, any>
): Generator<Node<Msg, any>> {
  yield node
  if (node._tag === "Element") {
    for (const child of node.children) yield* nodes(child)
  } else if (node._tag === "Child") {
    for (const child of slotNodes(node)) yield* nodes(child)
  }
}

const noNodes: ReadonlyArray<never> = []

/**
 * The nodes a child's parent passed for its slots, in the order they were
 * passed.
 *
 * @internal
 */
export const slotNodes = <Msg>(
  child: Child<Msg, any>
): ReadonlyArray<Node<Msg, any>> => {
  if (child.slots === undefined) return noNodes
  const out: Array<Node<Msg, any>> = []
  for (const name in child.slots) {
    out.push(...children<Msg>([child.slots[name]]))
  }
  return out
}
